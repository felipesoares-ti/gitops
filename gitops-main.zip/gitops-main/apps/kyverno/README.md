## Update Chart
1. Download do chart

   `helm pull kyverno/kyverno --version 3.0.6`
2. Copiar para nginx-chart (atualizar nome do pod):

    `kubectl cp -n charts kyverno-3.0.6.tgz nginx-helm-579847f7f9-n56t2:/usr/share/nginx/html/`
